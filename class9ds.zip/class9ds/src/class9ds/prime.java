/*
project name: class9ds
program:prime
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
takes prime numbers out of order queue 
*/
package class9ds;

import java.util.Queue;

public class prime {
    public int prime(Queue<Integer> order){
        int prime=0;
        prime=order.remove();
        return prime;
    }
}
