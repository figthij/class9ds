/*
project name: class9ds
program:multiples
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
is given prime number and is muliplied until it hits limit all numbers that are found are taken out of possible prime
*/
package class9ds;
import java.util.Stack;
public class multiples {
    public Stack<Integer> multiply(int prime){
        Stack<Integer> out = new Stack<>();
        int times=2;//amount of times prime is multiplied
        //2 so the prime number isn't taken out
        int not=prime*times;//numbers found not to be prime
        while(not<1000){
            out.add(not);
            times=times+1;
            not=prime*times;
        }
        return out;
    }
}
