/*
project name: class9ds
program:stack
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
searches for numbers to takke out
*/
package class9ds;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
public class search {
//move all numbers from one queue to another searching for instances of outed numbers
    public Queue<Integer> search(Stack<Integer> multiply,Queue<Integer> order){
        int out;
        int check;
        Queue<Integer> temp = new LinkedList();//used as a temp queue while checking
        for(int x=multiply.size();x>0;x--){//checks every case of multiply
            out=multiply.pop();
            for(int i=order.size();i>0;i--){//checks order and removes non prime numbers
                check=order.remove();
                if(out!=check){
                    temp.add(check);
                }
            }
            order=temp;
        }
        return order;
    }
}
