/*
project name: class9ds
program:queue
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
the queue used takes out the first value in it as it is prime and sends it to multiples to eliminate non prime numbers
*/
package class9ds;
import java.util.LinkedList;
import java.util.Queue;
public class queue {
    //makes queue from 2 to 999
    public Queue<Integer> ord(){
        Queue<Integer> order = new LinkedList<>();
        for(int x= 2; x<1000;x++){
            order.add(x);
        }
    return order;
    }
}
