/*
project name: class9ds
program:stack
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
deals with the stack containing all the prime numbers
*/
package class9ds;

import java.util.Stack;

public class stack {
    public Stack<Integer> primes(int prime,int times,Stack<Integer> p){
        if(times<100){
            p.add(prime);
        }
        return p;
    }
    
}
