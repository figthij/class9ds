/*
project name: class9ds
program:class9ds
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
finds first 100 prime numbers using eratosthenes
must have stacks and a queue
*/
package class9ds;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
public class Class9ds {
    public static void main(String[] args) {
        queue q= new queue();
        prime p = new prime();
        multiples m = new multiples();
        search sea= new search();
        Stack<Integer> example = new Stack<>();//used for checking progress
        Queue<Integer> order = new LinkedList<>();
        order=q.ord();
        int prime=0;//takes next prime number from order 
        for(int i=0;i<100;i++){
            prime=p.prime(order);//takes next prime number from order
  //      System.out.println(prime+ "PRIME");
            example.add(prime);
            order=sea.search(m.multiply(prime), order);
        }
        System.out.println("primes"+example);
        System.out.println(example.size());
    }
}
